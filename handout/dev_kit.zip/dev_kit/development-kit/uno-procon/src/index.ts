/**
 * @description load application
 */
exports = module.exports = require('./app');
exports = module.exports = require('./test-tool');
