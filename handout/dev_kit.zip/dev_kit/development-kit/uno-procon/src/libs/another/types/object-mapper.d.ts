declare module 'object-mapper' {
  function ObjectMapper(source: any, map: any, transform?: any): any;

  namespace ObjectMapper {}
  export = ObjectMapper;
}
