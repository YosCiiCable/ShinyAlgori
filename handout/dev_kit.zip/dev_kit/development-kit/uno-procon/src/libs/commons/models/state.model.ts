export interface StateModel {
  state: [
    {
      name: string;
      abbreviation: string;
    },
  ];
}
