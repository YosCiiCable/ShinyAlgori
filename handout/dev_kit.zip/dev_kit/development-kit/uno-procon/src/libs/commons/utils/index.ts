import { ObjectUtil } from './object.util';
import { StringUtil } from './string.util';

export class Utils {
  static objects = ObjectUtil;
  static strings = StringUtil;
}
