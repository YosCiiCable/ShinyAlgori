import { BullLib } from './bull.lib';

export class Schedule {
  public static bull = BullLib;
}
