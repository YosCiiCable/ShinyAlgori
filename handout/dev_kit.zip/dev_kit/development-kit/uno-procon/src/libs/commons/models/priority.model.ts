export enum Priority {
  low = 'low',
  normal = 'normal',
  medium = 'medium',
  high = 'high',
  critical = 'critical',
}
