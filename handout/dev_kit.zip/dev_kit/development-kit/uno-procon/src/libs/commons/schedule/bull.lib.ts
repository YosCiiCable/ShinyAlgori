/**
 * @description custom method support job kue
 * @since 2018/05/24
 * @ref https://github.com/Automattic/kue#securing-kue
 */

export class BullLib {}
