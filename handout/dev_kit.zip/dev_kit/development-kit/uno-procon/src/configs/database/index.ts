import mongodbConfig from './mongo.config';

export default function () {
  mongodbConfig();
}
