/**
 * @description export common interface
 */

export * from './app-config.model';
export * from './app-environment';
export * from './response-error';
