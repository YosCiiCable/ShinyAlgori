import { AppEnvironment } from './app-environment';

export interface AppConfigModel {
  ROOT: string;
  ENV: AppEnvironment;
}
