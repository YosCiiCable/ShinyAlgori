export default {
  // Error messages
  idRequiredField: 'Id is a required field.',
  invalidId: 'Id invalid',
  documentNotFound: 'Document not found',
};
