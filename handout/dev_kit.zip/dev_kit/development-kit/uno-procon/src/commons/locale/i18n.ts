import en from './languages/en';
import jp from './languages/jp';

export const messages = {
  en,
  jp,
};
