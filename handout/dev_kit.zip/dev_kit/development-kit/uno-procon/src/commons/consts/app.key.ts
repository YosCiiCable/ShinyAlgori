export class AppKey {
  // mongo references const
  static readonly DEALER: string = 'Dealer';
  static readonly PLAYER: string = 'Player';
  static readonly ACTIVITY: string = 'Activity';
}
