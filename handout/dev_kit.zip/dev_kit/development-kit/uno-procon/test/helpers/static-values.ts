export default {
  GLOBAL: {},
  DEALER_ID: '',
  DEALER_ID_1: '',
  DEALER_ID_3: '',
} as StaticValues;

interface StaticValues {
  GLOBAL: any;
  DEALER_ID: string;
  DEALER_ID_1: string;
  DEALER_ID_3: string;
}
